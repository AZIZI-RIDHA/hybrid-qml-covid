#!/bin/bash
echo running